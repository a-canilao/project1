def cleanTable():
	print "test"

def verifyUser():
	currentUser = system.security.getUsername()
	password = system.gui.passwordBox("Confirm Password")

	
	if password == None:
		return system.gui.warningBox("<html><p style='color:#FF0000;font-size:14px;font-weight:bold'>Need approved user to operate!</p>" , "Warning!!!")
	else:
		verify = system.security.validateUser(currentUser, password)
		if verify:
			return 	True
		else:
			return system.gui.errorBox("<html><p style='color:#FF0000;font-size:14px;font-weight:bold'>Incorrect Password!</p>")

def switchUser():
	newUser = system.gui.inputBox("Username:","")
	if newUser == None:
		return True
	if newUser == "":
		return system.gui.errorBox("<html><p style='color:#FF0000;font-size:14px;font-weight:bold'>Please provide a username!</p>")
	else:
		password = system.gui.passwordBox("Confirm Password")
		if password == None:
			return system.gui.warningBox("<html><p style='color:#FF0000;font-size:14px;font-weight:bold'>Please provide a password!</p>" , "Warning!!!")
		else:
			switch = system.security.switchUser(newUser, password) 
			if switch:
				return True
			else:
				return system.gui.errorBox("<html><p style='color:#FF0000;font-size:14px;font-weight:bold'>Incorrect Username or Password!</p>")		
				
def meterPop(event):
	param1 = event.source.meterName	
	window = system.nav.openWindow('Popups/Meter Info', {'meterName' : param1})

def trnPop(event):
	param1 = event.source.trnName
	window = system.nav.openWindow('Popups/Transformer Info', {'trnName': param1})

def trfioPop(event):
		param1 = event.source.trnName
		window = system.nav.openWindow('Popups/TRF IO Info', {'trnName': param1})
	
def hvacPop(event):
	param1 = event.source.hvacName
	window = system.nav.openWindow('Popups/HVAC Info', {'hvacName': param1})

def battPop(event):
		param1 = event.source.battName
		window = system.nav.openWindow('Popups/Battery Info', {'battName': param1})
	
	
def devicePop(event):

	param1 = event.source.Device_UDT.Meta.TagName
	mouseX = event.x		
	mouseY = event.y
	compX = event.source.getX()
	compY = event.source.getY()
	windowX = event.source.parent.getX()
	windowY = event.source.parent.getY()
	
	
	#print event.x, event.y, windowX, windowY
		
	if windowX < 250:
		window = system.nav.openWindow('Popups/Device Info', {'deviceName': param1})
		window.setLocation(mouseX+compX+windowX+300,mouseY+compY+windowY+0)
	#if windowY < 250:
	#	window = system.nav.openWindow('Popups/Device Info', {'deviceName': param1})
	#	window.setLocation(mouseX+compX+windowX+300,mouseY+compY+windowY+200)		
	else:
		window = system.nav.openWindow('Popups/Device Info', {'deviceName': param1})
		window.setLocation(mouseX+compX+windowX-100,mouseY+compY+windowY+0)

def currWindow():
	#desk = system.gui.getCurrentDesktop()
	return system.nav.desktop(0).getCurrentWindow()
	
def switchControl(event):
	
	if event.source.allowSource == 0:
		if Main.verifyUser():
			if event.source.Switch_UDT.Closed == 1:
				event.source.Switch_UDT.Open = 1
				event.source.Switch_UDT.Close = 0
				##### FOR TESTING #####
				event.source.Switch_UDT.Closed = 0
				event.source.Switch_UDT.Opened = 1
				return
								
			if event.source.Switch_UDT.Opened == 1:
				event.source.Switch_UDT.Open = 0
				event.source.Switch_UDT.Close = 1
				##### FOR TESTING #####
				event.source.Switch_UDT.Closed = 1
				event.source.Switch_UDT.Opened = 0
				return
	
	if event.source.nodeOutput == 1:
		if Main.verifyUser():
			if event.source.Switch_UDT.Closed == 1:
				event.source.Switch_UDT.Close = 0
				event.source.Switch_UDT.Open = 1
				##### FOR TESTING #####
				event.source.Switch_UDT.Closed = 0
				event.source.Switch_UDT.Opened = 1
				return
						
			else:
				event.source.Switch_UDT.Open = 0
				event.source.Switch_UDT.Close = 1
				##### FOR TESTING #####
				event.source.Switch_UDT.Closed = 1
				event.source.Switch_UDT.Opened = 0
				return	
		else:
			if event.source.Switch_UDT.Closed == 1:
				if Main.verifyUser():
					event.source.Switch_UDT.Close = 0
					event.source.Switch_UDT.Open = 1
					##### FOR TESTING #####
					event.source.Switch_UDT.Closed = 0
					event.source.Switch_UDT.Opened = 1
					return
	
			else:
				system.gui.errorBox("Warning: The switch: " +event.source.SourceDetails+ " are still disconnected.""\n\n This switch can't be override", "System Alert")

def breakerControl(event):
	
	if event.source.allowSource == 0:
		if Main.verifyUser():
			if event.source.Breaker_UDT.Closed == 1:
				event.source.Breaker_UDT.Open = 1
				event.source.Breaker_UDT.Close = 0
				##### FOR TESTING #####
				event.source.Breaker_UDT.Closed = 0
				event.source.Breaker_UDT.Opened = 1
				return
								
			if event.source.Breaker_UDT.Opened == 1:
				event.source.Breaker_UDT.Open = 0
				event.source.Breaker_UDT.Close = 1
				##### FOR TESTING #####
				event.source.Breaker_UDT.Closed = 1
				event.source.Breaker_UDT.Opened = 0
				return
	
	if event.source.nodeOutput == 1:
		if Main.verifyUser():
			if event.source.Breaker_UDT.Closed == 1:
				event.source.Breaker_UDT.Close = 0
				event.source.Breaker_UDT.Open = 1
				##### FOR TESTING #####
				event.source.Breaker_UDT.Closed = 0
				event.source.Breaker_UDT.Opened = 1
				return
						
			else:
				event.source.Breaker_UDT.Open = 0
				event.source.Breaker_UDT.Close = 1
				##### FOR TESTING #####
				event.source.Breaker_UDT.Closed = 1
				event.source.Breaker_UDT.Opened = 0
				return	
		else:
			if event.source.Breaker_UDT.Closed == 1:
				if Main.verifyUser():
					event.source.Breaker_UDT.Close = 0
					event.source.Breaker_UDT.Open = 1
					##### FOR TESTING #####
					event.source.Breaker_UDT.Closed = 0

def multiMonitor():
	screens = system.gui.getScreens()
	if len(screens) > 1:
		windowsToOpen = ["Main Windows/SLD/HV","Navigation"]
		system.gui.openDesktop(screen=1, windows=windowsToOpen, y=1, handle="", title="")
